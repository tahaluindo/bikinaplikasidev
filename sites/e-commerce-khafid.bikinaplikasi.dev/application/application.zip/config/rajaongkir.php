<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * RajaOngkir API Key
 * Silakan daftar akun di RajaOngkir.com untuk mendapatkan API Key
 * //rajaongkir.com/akun/daftar
 */
$config['rajaongkir_api_key'] = "e86e8d1bab75ac940a77cc3a45d84b4f";

/**
 * RajaOngkir account type: starter or basic
 * //rajaongkir.com/dokumentasi#akun-ringkasan
 * 
 */
$config['rajaongkir_account_type'] = "starter";
