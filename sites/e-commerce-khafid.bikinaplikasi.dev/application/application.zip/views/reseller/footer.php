
<strong>Copyright &copy; 2021 - <?php echo date('Y'); ?> <a target='_BLANK' href="//www.youtube.com/channel/UCCwTxcAOp84F55kov_TICsQ"></a>.</strong> All rights reserved.