<p class='sidebar-title'><span class='glyphicon glyphicon-remove'></span> <strong>Maaf, Reset Password Gagal!</strong></p>
<center style='padding:50px'>
<style>
.lupa {
	width:50%;
}
</style>
<h2>Gagal Reset Password!!!</h2>
Email <b style='color:red'><?php echo $email; ?></b> Tidak ditemukan Didatabase. Silakan coba lagi...<br>
Silahkan Menghubungi kami <a href='<?php echo base_url(); ?>/contact'>disini</a>, jika anda mengalami kesulitan.<br>

<br><br>
</center>