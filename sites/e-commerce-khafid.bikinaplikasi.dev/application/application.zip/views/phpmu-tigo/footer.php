<?php
echo "<div class='wrapper '>
	<h3 style='text-align:center' class='footer '> Copyright 2021. All Rights reserved.<br/>Edit by . <a style='color:orange' href='//kangeann.my.id/khafid/'>ACH.KHAFID SALIM</a> <br> PULAU PINTAR KANGEAN BERBASIS TEKNOLOGI INFORMASI DI ERA INDUSTRI 4.0</h3>
</div>";

