
<strong>Copyright &copy; 2021 - <?php echo date('Y'); ?> <a target='_BLANK' href="//kangeann.my.id/khafid"> ACH KHAFID SALIM</a>.</strong> All rights reserved.