    @extends('layouts.app')
    @section('content')
    @include('layouts.user.laporan.index')
    @endsection