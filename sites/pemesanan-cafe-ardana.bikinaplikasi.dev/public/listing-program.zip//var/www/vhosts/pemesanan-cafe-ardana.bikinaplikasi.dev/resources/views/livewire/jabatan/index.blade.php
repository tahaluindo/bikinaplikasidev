@section("content")
    @livewire('jabatan.index-table')
@endsection