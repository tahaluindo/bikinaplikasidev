    @extends('layouts.app')
    @section('content')
    @include('layouts.produk.laporan.index')
    @endsection