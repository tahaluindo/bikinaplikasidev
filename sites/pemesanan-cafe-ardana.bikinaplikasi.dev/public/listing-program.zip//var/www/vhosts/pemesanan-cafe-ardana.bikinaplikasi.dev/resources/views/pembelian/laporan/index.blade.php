    @extends('layouts.app')
    @section('content')
    @include('layouts.pembelian.laporan.index')
    @endsection