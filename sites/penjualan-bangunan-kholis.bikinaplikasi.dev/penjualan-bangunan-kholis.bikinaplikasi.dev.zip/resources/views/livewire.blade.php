

<head>
    
    @livewireStyles
</head>
<body>
    <livewire:counter />

    

    @livewireScripts
</body>
</html>
 

