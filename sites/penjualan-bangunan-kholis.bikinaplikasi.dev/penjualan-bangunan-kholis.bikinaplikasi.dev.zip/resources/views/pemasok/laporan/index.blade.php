    @extends('layouts.app')
    @section('content')
    @include('layouts.pemasok.laporan.index')
    @endsection