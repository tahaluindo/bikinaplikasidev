    @extends('layouts.app')
    @section('content')
    @include('layouts.pelanggan.laporan.index')
    @endsection