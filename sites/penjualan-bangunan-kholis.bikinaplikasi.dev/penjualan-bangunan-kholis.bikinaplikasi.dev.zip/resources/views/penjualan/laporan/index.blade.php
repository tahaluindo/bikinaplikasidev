    @extends('layouts.app')
    @section('content')
    @include('layouts.penjualan.laporan.index')
    @endsection