    @extends('layouts.app')
    @section('content')
    @include('layouts.kategori.laporan.index')
    @endsection